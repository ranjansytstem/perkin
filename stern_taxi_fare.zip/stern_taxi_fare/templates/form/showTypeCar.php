<?php
function showTypeCar($class_full_row,$class) {
			
			$args = array(
				'post_type' => 'stern_categoryCar',
				'nopaging' => true,
				'order'     => 'ASC',
				'orderby' => 'meta_value',
				'meta_key' => 'orderCategoryCar'
			);
			$allCategoryCar = get_posts( $args );	

			
			
			


			if (getShow_dropdown_typecar()=='false') {
				$visibility = "display: none;";
			} else {
				$visibility = "";
			}
			
		/*	
		$distance=399;
		$selectedCarTypeId=68;
			 $allTypeCars = getAllCarsByCateg($selectedCarTypeId);
			   	foreach ( $allTypeCars as $post ) { setup_postdata( $post );		 
					 $oTypeCar = new typeCar($post->ID); 
				      $car_type=$oTypeCar->getcarType();
					  $car_new=array();
					  echo $car_type;
					     echo "<br>";	
					$car_new=   explode("-", $car_type);
			               $min= $car_new[0];
						   $max=$car_new[1];
						 
					 if($distance>$min&&$distance<$max)
					 {
						 
				          	$km_fare = $oTypeCar->getfarePerDistance();
							
							 $selected_post_id=$post->ID;
				
				
					 }
					
					  
				}	
               echo "<br>";				
			echo $km_fare;
			*/
			
			?>

			<div id="typeCarsDropDown" <?php echo $class_full_row; ?> style="padding-top: 15px;<?php echo $visibility ?>">				
				<?php if (showlabel()) : ?>
					<label for="cartypes"><?php _e('Car Type', 'stern_taxi_fare'); ?></label>
				<?php endif; ?>

				
				<select name="cartypes" id="cartypes" class="<?php echo $class; ?>" data-width="100%" style="padding-left: 15px; float: right;" data-none-selected-text="<?php _e('No cars available', 'stern_taxi_fare'); ?>">
					
					<?php foreach ( $allCategoryCar as $postCateg ) : setup_postdata( $postCateg ); ?>
						<?php $oCategoryCar = new categoryCar($postCateg->ID); ?>
				
							<?php $allTypeCars = getAllCarsByCateg($oCategoryCar->getid()); ?>
						
								<option data-icon="glyphicon-road" value="<?php echo $oCategoryCar->getid(); ?>">
									<?php echo $oCategoryCar->getnameCategoryCar(); ?>
								</option>
								
					
							
					<?php endforeach; ?>

				</select>

			</div>


<?php


	
}	

